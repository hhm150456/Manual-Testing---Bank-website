package utils;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class TestData {
    private String name;
    private String email;
    private String password;
    private String firstName;
    private String lastName;
    private String address;
    private String state;
    private String city;
    private String zipcode;
    private String phoneNumber;
    private String orderMessage;
    private String cardName;
    private String cardNumber;
    private String cvc;
    private String expiryMonth;
    private String expiryYear;
    private String review;
    private String RecommendedItemXpath;
    // Getters and setters

    public TestData() {
        // Load the JSON data from the file
        try (FileReader reader = new FileReader("src/test/resources/testData.json")) {
            Gson gson = new Gson();
            JsonObject testDataJson = gson.fromJson(reader, JsonObject.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getName() {
        return name;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getAddress() {
        return address;
    }

    public String getState() {
        return state;
    }

    public String getCity() {
        return city;
    }

    public String getZipcode() {
        return zipcode;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getOrderMessage() {
        return orderMessage;
    }

    public String getCardName() {
        return cardName;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public String getCvc() {
        return cvc;
    }

    public String getExpiryMonth() {
        return expiryMonth;
    }

    public String getExpiryYear() {
        return expiryYear;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public String getRecommendedItemXpath() {
        return RecommendedItemXpath;
    }

    public void setRecommendedItemXpath(String recommendedItemXpath) {
        RecommendedItemXpath = recommendedItemXpath;
    }
}

