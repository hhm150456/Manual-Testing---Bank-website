package Tests;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.BaseTest;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class AddressDetailsInCheckoutTest extends BaseTest {

    @Test
    public void testAddressDetailsOnCheckout() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        driver.findElement(By.linkText("Signup / Login")).click();

        // Register steps
        String name = "UserTest", email = "user" + System.currentTimeMillis() + "@mail.com";
        driver.findElement(By.name("name")).sendKeys(name);
        driver.findElement(By.xpath("//input[@data-qa='signup-email']")).sendKeys(email);
        driver.findElement(By.xpath("//button[text()='Signup']")).click();

        WebElement gender = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("id_gender1")));
        gender.click();

        // Fill registration form
        driver.findElement(By.id("password")).sendKeys("123456");
        driver.findElement(By.id("first_name")).sendKeys("John");
        driver.findElement(By.id("last_name")).sendKeys("Doe");
        driver.findElement(By.id("address1")).sendKeys("123 Elm St");
        driver.findElement(By.id("state")).sendKeys("CA");
        driver.findElement(By.id("city")).sendKeys("LA");
        driver.findElement(By.id("zipcode")).sendKeys("90001");
        driver.findElement(By.id("mobile_number")).sendKeys("1234567890");
        driver.findElement(By.xpath("//button[text()='Create Account']")).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//b[text()='Account Created!']")));
        driver.findElement(By.xpath("//a[text()='Continue']")).click();

        // Add product and go to cart
        driver.findElement(By.xpath("(//a[text()='Add to cart'])[1]")).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//u[text()='View Cart']"))).click();

        driver.findElement(By.xpath("//a[text()='Proceed To Checkout']")).click();

        // Verify delivery and billing address
        String deliveryAddress = driver.findElement(By.id("address_delivery")).getText();
        String billingAddress = driver.findElement(By.id("address_invoice")).getText();

        assertTrue(deliveryAddress.contains("John") && billingAddress.contains("John"));
    }
}
