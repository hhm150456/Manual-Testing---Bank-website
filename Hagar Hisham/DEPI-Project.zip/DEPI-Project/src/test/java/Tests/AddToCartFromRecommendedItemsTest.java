package Tests;

import utils.TestData;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.BaseTest;
import utils.TestData;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class AddToCartFromRecommendedItemsTest extends BaseTest {

    @Test
    public void testAddToCartFromRecommended() {
        // Load test data from JSON
        TestData testData = new TestData();
        String addToCartXpath = testData.getRecommendedItemXpath(); // Fetch the XPath for item1

        // Initialize WebDriverWait
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Scroll to the bottom of the page
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");

        // Wait for the "recommended items" section to be visible
        WebElement recommendedItemsSection = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='recommended items']")));

        // Click the "Add to cart" button of the first recommended item (using the data from JSON)
        WebElement addToCartButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(addToCartXpath)));
        addToCartButton.click();

        // Wait for the "View Cart" link to be visible and click it
        WebElement viewCartLink = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//u[text()='View Cart']")));
        viewCartLink.click();

        // Verify that the page contains "Shopping Cart"
        assertTrue(driver.getPageSource().contains("Shopping Cart"));
    }
}
