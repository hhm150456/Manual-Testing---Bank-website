package Tests;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.BaseTest;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class ScrollWithArrowTest extends BaseTest {

    @Test
    public void testScrollWithArrow() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Step 3: Verify home page is visible
        WebElement homeLink = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()=' Home']")));
        assertTrue(homeLink.isDisplayed(), "Home page is not visible");

        // Step 4: Scroll down to bottom of page
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight);");

        // Step 5: Verify 'SUBSCRIPTION' is visible
        WebElement subscriptionText = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Subscription']")));
        assertTrue(subscriptionText.isDisplayed(), "'SUBSCRIPTION' text is not visible");

        // Step 6: Click scroll-up arrow
        WebElement scrollUpButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("scrollUp")));
        scrollUpButton.click();

        // Step 7: Verify that page is scrolled up and 'Full-Fledged practice website for Automation Engineers' text is visible
        WebElement headlineText = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Full-Fledged practice website for Automation Engineers')]")));
        assertTrue(headlineText.isDisplayed(), "Top banner text not visible after scroll up");
    }
}
