package Tests;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.BaseTest;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class ScrollWithoutArrowTest extends BaseTest {

    @Test
    public void testScrollWithoutArrow() {
        // Create WebDriverWait object
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Step 3: Verify home page is visible
        WebElement homeLink = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()=' Home']")));
        assertTrue(homeLink.isDisplayed(), "Home page is not visible");

        // Step 4: Scroll down to bottom of page
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight);");

        // Step 5: Verify 'SUBSCRIPTION' is visible
        WebElement subscriptionText = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Subscription']")));
        assertTrue(subscriptionText.isDisplayed(), "'SUBSCRIPTION' text is not visible");

        // Step 6: Scroll up to top of page (no arrow)
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, 0);");

        // Step 7: Verify specific text is visible
        WebElement headlineText = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Full-Fledged practice website for Automation Engineers')]")));
        assertTrue(headlineText.isDisplayed(), "Top banner text not visible after scroll up");
    }
}
