package Tests;

import utils.TestData;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import utils.BaseTest;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class AddReviewOnProductTest extends BaseTest {

    @Test
    public void addReviewOnProduct() {
        // Load test data from JSON (e.g., name, email, and review details)
        TestData testData = loadTestData("testData.json", TestData.class); // Assuming you have a loadTestData method in BaseTest

        // Navigate to Products and check if "All Products" is visible
        driver.findElement(By.xpath("//a[text()=' Products']")).click();
        assertTrue(driver.findElement(By.xpath("//h2[text()='All Products']")).isDisplayed());

        // Click on the first product and verify "Write Your Review" button is visible
        driver.findElement(By.xpath("(//a[text()='View Product'])[1]")).click();
        WebElement writeReviewButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Write Your Review']")));
        assertTrue(writeReviewButton.isDisplayed());

        // Fill out the review form with data from JSON
        driver.findElement(By.id("name")).sendKeys(testData.getName()); // Example: "John Doe"
        driver.findElement(By.id("email")).sendKeys(testData.getEmail()); // Example: "john@example.com"
        driver.findElement(By.id("review")).sendKeys(testData.getReview()); // Example: "Great product!"

        // Submit the review
        driver.findElement(By.id("button-review")).click();

        // Verify the success message after submission
        WebElement successMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Thank you for your review.']")));
        assertTrue(successMessage.isDisplayed());
    }
}
