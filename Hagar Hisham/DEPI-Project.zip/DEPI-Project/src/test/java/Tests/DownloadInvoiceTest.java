package Tests;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import utils.BaseTest;
import static org.junit.jupiter.api.Assertions.assertTrue;
import utils.TestData;

public class DownloadInvoiceTest extends BaseTest {

    @Test
    public void testDownloadInvoiceAfterOrder() {
        // Load test data from JSON (e.g., account and product details)
        TestData testData = loadTestData("testData.json", TestData.class);  // You can define your own test data class

        // Navigate to Products and add a product to the cart
        driver.findElement(By.linkText("Products")).click();
        WebElement addToCartButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Add to cart']")));
        addToCartButton.click();

        WebElement viewCartButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//u[text()='View Cart']")));
        viewCartButton.click();

        // Proceed to checkout
        WebElement proceedToCheckoutButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Proceed To Checkout']")));
        proceedToCheckoutButton.click();

        // Register a new user (using data from JSON)
        driver.findElement(By.linkText("Register / Login")).click();
        String email = testData.getEmail(); // Example: Load dynamic email or any test data from JSON
        driver.findElement(By.name("name")).sendKeys(testData.getName());
        driver.findElement(By.xpath("//input[@data-qa='signup-email']")).sendKeys(email);
        driver.findElement(By.xpath("//button[text()='Signup']")).click();

        // Fill out registration details
        WebElement genderOption = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("id_gender1")));
        genderOption.click();

        driver.findElement(By.id("password")).sendKeys(testData.getPassword());
        driver.findElement(By.id("first_name")).sendKeys(testData.getFirstName());
        driver.findElement(By.id("last_name")).sendKeys(testData.getLastName());
        driver.findElement(By.id("address1")).sendKeys(testData.getAddress());
        driver.findElement(By.id("state")).sendKeys(testData.getState());
        driver.findElement(By.id("city")).sendKeys(testData.getCity());
        driver.findElement(By.id("zipcode")).sendKeys(testData.getZipcode());
        driver.findElement(By.id("mobile_number")).sendKeys(testData.getPhoneNumber());
        driver.findElement(By.xpath("//button[text()='Create Account']")).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//b[text()='Account Created!']")));
        driver.findElement(By.xpath("//a[text()='Continue']")).click();

        // Navigate to Cart and proceed to checkout
        driver.findElement(By.linkText("Cart")).click();
        proceedToCheckoutButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Proceed To Checkout']")));
        proceedToCheckoutButton.click();

        // Place the order
        driver.findElement(By.name("message")).sendKeys(testData.getOrderMessage());
        driver.findElement(By.xpath("//a[text()='Place Order']")).click();

        // Enter payment details
        driver.findElement(By.name("name_on_card")).sendKeys(testData.getCardName());
        driver.findElement(By.name("card_number")).sendKeys(testData.getCardNumber());
        driver.findElement(By.name("cvc")).sendKeys(testData.getCvc());
        driver.findElement(By.name("expiry_month")).sendKeys(testData.getExpiryMonth());
        driver.findElement(By.name("expiry_year")).sendKeys(testData.getExpiryYear());
        driver.findElement(By.id("submit")).click();

        // Verify order confirmation
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//b[text()='Order Placed!']")));
        assertTrue(driver.getPageSource().contains("Order Placed!"));

        // Download invoice
        WebElement downloadInvoiceButton = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Download Invoice")));
        downloadInvoiceButton.click();

        // Note: Verifying the downloaded file would require additional setup and is not included here.
    }
}
